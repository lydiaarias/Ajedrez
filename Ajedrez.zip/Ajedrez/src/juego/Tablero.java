package juego;

import java.util.Scanner; 

public class Tablero 
{
	public static void main(String[] args)
	{
		int filas, col; 
		
		for(col = 1;  col<=5; col++)
		{
			for(filas = 1; filas<=5; filas++)
			{
				System.out.print("██");
				System.out.print("  ");
			}
			System.out.println("");
			for(filas = 1; filas<=5; filas++)
			{
				System.out.print("  ");
				System.out.print("██");
			}
			System.out.println(""); 

		}
	}
}
